import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-lineup',
  templateUrl: './product-lineup.component.html',
  styleUrls: ['./product-lineup.component.scss']
})
export class ProductLineupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
